import math

import matplotlib.pyplot as plt
import numpy as np
from data import DataSet
from lstm import *

class Net(object):
    def __init__(self, dr, input_size, hidden_size, output_size, times=4, bias=True):
        self.dr = dr
        self.loss_fun = LossFunction()
        self.times = times
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.bias = bias
        self.lstmcell = []
        for i in range (self.times):
            self.lstmcell.append(LstmCell(input_size, hidden_size, bias))


    def forward(self, X):
        hp = np.zeros((1, self.hidden_size))
        cp = np.zeros((1, self.hidden_size))
        for i in range(self.times):
            self.lstmcell[i].forward(X, hp, cp, self.W, self.U, self.bh)
            hp = self.lstmcell[i].h
            cp = self.lstmcell[i].c

    def backward(self, Y):
        hp = []
        cp = []
        t1 = self.times - 1
        dh = self.lstmcell[t1].h - Y
        hp = self.lstmcell[t1-1].h
        cp = self.lstmcell[t1-1].c
        self.lstmcell[t1].backward(hp, cp, dh)

        dh = []
        for i in range(t1-1, 0, -1):
            dh = self.lstmcell[i+1].dh
            hp = self.lstmcell[i - 1].h
            cp = self.lstmcell[i - 1].c
            self.lstmcell[i].backward(hp, cp, dh)

        dh = self.lstmcell[1].dh
        hp = np.zeros((self.batch_size, self.hidden_size))
        cp = np.zeros((self.batch_size, self.hidden_size))
        self.lstmcell[0].backward(hp, cp, dh)

    def check_loss(self, X, Y):
        self.forward(X)
        # loss_list = np.zeros((1, self.output_size))
        # acc_list = np.zeros((1, self.output_size))
        # print(self.lstmcell[self.times - 1].h, Y)
        h_r = []
        for i in range(self.times):
            h_r.append(self.lstmcell[i].h)
        h_r = np.array(h_r)
        result = h_r.reshape((-1, self.times))
        loss_list, acc_list = self.loss_fun.CheckLoss(result, Y)
        # output = np.concatenate((self.linearcell[0].a, self.linearcell[1].a, self.linearcell[2].a, self.linearcell[3].a), axis=1)
        correct = acc_list / acc_list.shape[0]
        acc = np.sum(correct) / X.shape[0]
        loss = np.mean(loss_list)
        return loss, acc, result

    def init_params_uniform(self, shape):
        p = []
        std = 1.0 / math.sqrt(self.hidden_size)
        p = np.random.uniform(-std, std, shape)
        return p

    def train(self, batch_size, checkpoint=0.1, max_epoch=100, eta=0.1):
        self.batch_size = batch_size
        # Try different initialize method
        # self.U = np.random.random((4 * self.input_size, self.hidden_size))
        # self.W = np.random.random((4 * self.hidden_size, self.hidden_size))
        self.U = self.init_params_uniform((4 * self.input_size, self.hidden_size))
        self.W = self.init_params_uniform((4 * self.hidden_size, self.hidden_size))
        self.bh = np.zeros((4, self.hidden_size))

        max_iteration = math.floor(self.dr.num_train / batch_size)   #向上取整
        checkpoint_iteration = (int)(math.floor(max_iteration * checkpoint))

        LOSS = []
        for epoch in range(max_epoch):
            # TODO
            dr.Shuffle()
            for iteration in range(max_iteration):
                # TODO getData
                batch_x, batch_y = self.dr.GetBatchTrainSample(batch_size, iteration)
                self.forward(batch_x)
                self.backward(batch_y)
                #update
                for i in range(self.times):
                    self.lstmcell[i].merge_params()
                    self.U = self.U - self.lstmcell[i].dU * eta / self.batch_size
                    self.W = self.W - self.lstmcell[i].dW * eta / self.batch_size
                    if self.bias:
                        self.bh = self.bh - self.lstmcell[i].db * eta / self.batch_size
                # loss
                total_iteration = epoch * max_iteration + iteration
                if (total_iteration + 1) % checkpoint_iteration == 0:
                    # TODO
                    X, Y = self.dr.GetValidationSet()
                    loss, acc, _ = self.check_loss(X, Y)
                    LOSS.append(loss)
                    # self.loss_trace.Add(epoch, total_iteration, None, None, loss, acc, None)
                    print(epoch, total_iteration)
                    print(str.format("loss={0:6f}, acc={1:6f}", loss, acc))
            if acc == 1.0:
                print("ok")
                break
        plt.plot(LOSS)
        plt.show()

    def test(self):
        print("testing...")
        # TODO
        X, Y = [], []
        count = X.shape[0]
        loss, acc, result = self.check_loss(X, Y)
        print(str.format(f"loss={0:6f}, acc={1:6f}", loss, acc))
        r = np.random.randint(0, count, 10)
        for i in range(10):
            idx = r[i]
            x1 = X[idx, :, 0]
            x2 = X[idx, :, 1]
            print(" x1:", reverse(x1))
            print("-x2:", reverse(x2))
            x1_dec = int("".join(map(str, reverse(x1))), 2)
            x2_dec = int("".join(map(str, reverse(x2))), 2)
            print("{0} - {1} = {2}".format(x1_dec, x2_dec, (x1_dec - x2_dec)))
            print("====================")


def reverse(self, a):
    l = a.tolist()
    l.reverse()
    return l

if __name__ == '__main__':
    #TODO
    dr = DataSet()
    dr.InitTrainDate(num_feature=64)
    count = dr.num_train
    input_size = dr.num_feature
    hidden_size = dr.num_feature
    output_size = 1

    n = Net(dr, input_size, hidden_size, output_size, bias=True)
    n.train(batch_size=16, checkpoint=0.1, eta=0.01)
    # n.test()